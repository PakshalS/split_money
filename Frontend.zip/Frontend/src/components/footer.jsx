import React from 'react'

const Footer = () => {
  return (
    <div className=" bg-gray-950">
    <img src="src/assets/footer.png" alt="Footer Decoration" className="w-full" />
  </div>
  )
}

export default Footer