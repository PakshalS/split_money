import React from 'react'

const Dashboard = () => {
  return (
    <div>Balance</div>
  )
}

export default Dashboard