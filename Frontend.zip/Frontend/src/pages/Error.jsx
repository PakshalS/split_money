import React from 'react'

const NoPage = () => {
  return (
    <div className='text-6xl font-bold flex h-screen items-center justify-center'>Error 404 ! Not Found !</div>
  )
}

export default NoPage