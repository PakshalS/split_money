import React from 'react'

const Group = () => {
  return (
    <div>Group</div>
  )
}

export default Group